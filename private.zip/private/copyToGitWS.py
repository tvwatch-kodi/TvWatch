#-*- coding: utf-8 -*-

import os
import zipfile
import random
from datetime import date

GIT_ROOT = "C:\\GitWorkspace\\Perso\\TvWatch\\"
KODI_ROOT = "C:\\Users\\212600520\\AppData\\Roaming\\Kodi\\addons\\plugin.video.tvwatch"
RELEASE = "0.0.0"

def main():

    print "*** TvWatch for Kodi ***"

    response = raw_input("\nDo you want to proceed with the install ? (Y/N) ").lower()

    if response == "y" or response == "yes":

        print "## RESET FILES IN SOURCE FOLDER..."
        rmdir(GIT_ROOT + "source\\resources")
        rmfile(GIT_ROOT + "source\\addon.xml")
        rmfile(GIT_ROOT + "source\\changelog.txt")
        rmfile(GIT_ROOT + "source\\default.py")
        rmfile(GIT_ROOT + "source\\fanart.png")
        rmfile(GIT_ROOT + "source\\icon.png")

        print "## COPYING FILES TO SOURCE FOLDER..."
        cpdir(KODI_ROOT, GIT_ROOT + "source")

        print "## REMOVE .PY* FILES FROM SOURCE FOLDER..."
        dirnames = ['source']
        while len(dirnames) != 0:
            for dir in dirnames:
                for (dirpath, dirnames, filenames) in os.walk(GIT_ROOT + dir):
                    for f in filenames:
                        if f.endswith(".pyo") or f.endswith(".pyd") or f.endswith(".pyi") or f.endswith(".pyc"):
                            print dirpath + '\\' + f
                            rmfile(dirpath + '\\' + f)

        response = raw_input("\nDo you want to update changelog.txt file ? (Y/N) [Default Y] ").lower()
        if response == "y" or response == "yes" or response == "":
            openFile(GIT_ROOT + "source\\changelog.txt")
            raw_input("\nPress Enter to continue...")

        RELEASE = raw_input("\nPlease enter version number in X.Y.Z format ")
        try:
            version = int(RELEASE.replace(".",""))
        except:
            print "Please enter a valid version number "
        if len(RELEASE.split(".")) == 3 and version > 0:

            changelog(RELEASE)
            addonXML('source', RELEASE)
            addonXML('repository', RELEASE)

            print "## CREATE THE RELEASE ZIP FILE..."
            zipName = "C:\\plugin.video.tvwatch-%s.zip" % (RELEASE)
            os.system("mkdir C:\\plugin.video.tvwatch")
            cpdir(GIT_ROOT + "source", "C:\\plugin.video.tvwatch")
            zipdir("C:\\plugin.video.tvwatch", zipName)
            rmdir("C:\\plugin.video.tvwatch")

            rmfile(GIT_ROOT + "repository\\plugin.video.tvwatch\\plugin.video.tvwatch*.zip")
            cpfile(zipName, GIT_ROOT + "repository\\plugin.video.tvwatch\\")
            cpfile(zipName, GIT_ROOT + "releases\\")
            rmfile(zipName)

            print "## GENERATE A NEW ADDON.XML.MD5 FILE..."
            generateMD5()

    raw_input("\nPress Enter to quit...")

def rmdir(path):
    os.system("rmdir /s /q " + path)

def rmfile(path):
    os.system("del /f /q " + path)

def cpdir(source, destination):
    os.system("xcopy /e /h /y " + source + " " + destination)

def cpfile(source, destination):
    os.system("copy /y " + source + " " + destination)

def zipdir(path, zipName):
    ziph = zipfile.ZipFile(zipName, 'w', zipfile.ZIP_DEFLATED)
    for root, dirs, files in os.walk(path):
        for f in files:
            ziph.write(os.path.join(root, f))
    ziph.close()

def generateMD5():
    f = open(GIT_ROOT + 'repository\\addon.xml.md5', 'w')
    f.write(''.join(random.choice('0123456789abcdef') for _ in range(32)))
    f.close()

def changelog(version):
    f = open(GIT_ROOT + 'source\\changelog.txt', 'r')
    content = ""
    for line in f.readlines():
        if "Current Version" in line:
            today = date.today()
            content += "- Current Version %s - %s.%s.%s\n" % (version, today.day, today.month, today.year)
        else:
            content += line
    f.close()
    f = open(GIT_ROOT + 'source\\changelog.txt', 'w')
    f.write(content)
    f.close()

def addonXML(folder, version):
    f = open(GIT_ROOT + folder + '\\addon.xml', 'r')
    content = ""
    for line in f.readlines():
        if 'id="plugin.video.tvwatch" name="TvWatch" version=' in line:
            today = date.today()
            content += '<addon id="plugin.video.tvwatch" name="TvWatch" version="%s" provider-name="Primatech">\n' % (version)
        else:
            content += line
    f.close()
    f = open(GIT_ROOT + folder + '\\addon.xml', 'w')
    f.write(content)
    f.close()

def openFile(path):
    os.system("\"C:\\Program Files\\Notepad++\\notepad++.exe\" " + path)

main()
