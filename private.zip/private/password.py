#-*- coding: utf-8 -*-

import hashlib, uuid
# import random

class cPassword:

    def set_password(self, raw_password):
        salt = uuid.uuid4().hex
        hsh = hashlib.sha1(raw_password + salt).hexdigest()
        enc_password = "%s$%s" % (salt, hsh)
        return enc_password

    def check_password(self, raw_password, enc_password):
        salt, hsh = enc_password.split("$")
        return hsh == hashlib.sha1(raw_password + salt).hexdigest()

# raw_password = random.randint(1511000000, 1511999999)
# enc_password = set_password(str(raw_password))
