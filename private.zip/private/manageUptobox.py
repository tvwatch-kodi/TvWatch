#-*- coding: utf-8 -*-

print "*** Manage Uptobox accounts ***\n"

from mySqlDB import cMySqlDB
from excel import cClientManager

mySqlDB = cMySqlDB()
excel = cClientManager('server')

COUNTRY   = 1
CITY      = 2
SERVER    = 3
XFSS      = 4

def updateDatabase(max):
    for i in range(2, max):
        meta = {}
        meta['country'] = excel.read(i, COUNTRY)
        meta['city'] = excel.read(i, CITY)
        meta['server'] = excel.read(i, SERVER)
        meta['xfss'] = '0'

        if not mySqlDB.insertContentServer(meta):
            mySqlDB.updateContentServer(meta)
    print "*** Database updated successfully ***"

def updateExcel(max):
    force = True
    for i in range(2, max):
        entry = mySqlDB.getContentByServer(str(excel.read(i, SERVER)))
        if entry:
            excel.write(i, XFSS, entry[4], force)
    print "*** Excel updated successfully ***"

def resetTableServer():
    mySqlDB.deleteTableServer()
    mySqlDB.createTableServer()

#################################################################################################
if excel.getFirstEmptyRowByCol(COUNTRY) != excel.getFirstEmptyRowByCol(CITY) or \
   excel.getFirstEmptyRowByCol(CITY) != excel.getFirstEmptyRowByCol(SERVER) or \
   excel.getFirstEmptyRowByCol(SERVER) != excel.getFirstEmptyRowByCol(COUNTRY):
    print "ERROR: Mismatch between COUNTRY/CITY/SERVER rows"
    quit()

# USE WITH CAUTION
# resetTableServer()
# print "*** Table Reset Successfully ***"
##################

emptyServerRow = excel.getFirstEmptyRowByCol(SERVER)
updateDatabase(emptyServerRow)
updateExcel(emptyServerRow)

for i in mySqlDB.getContentServer():
   print i

print
mySqlDB.getDbSize()

del excel
del mySqlDB

raw_input("\nPress Enter to quit...")
