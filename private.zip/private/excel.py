#-*- coding: utf-8 -*-

from openpyxl import load_workbook
from openpyxl.styles import Border
from openpyxl.styles import Side
from openpyxl.styles import PatternFill
from openpyxl.styles import Font
from openpyxl.styles import GradientFill
from openpyxl.styles import Alignment
from datetime import date, datetime

NAME = 'client_manager.xlsx'

class cClientManager:

    def __init__(self, wsName):
        try:
            self.wb = load_workbook(filename=NAME)
            self.ws = self.wb[wsName]
        except Exception as e:
            print "load_workbook error: {}".format(e)

    def __del__(self):
        try:
            self.style_range()
            self.wb.save(NAME)
        except Exception as e:
            print "save error: {}".format(e)

    def write(self, r, c, data, force=False):
        try:
            if self.read(r,c) == None or force:
                self.ws.cell(column=c, row=r, value=data)
            else:
                print "Can't overwrite data (%s), use force instead" % (data)
        except Exception as e:
            print "write error: {}".format(e)

    def read(self, r, c):
        val = None
        try:
            val = self.ws.cell(column=c, row=r).value
            if type(val) is datetime:
                val = u"%s/%s/%s" % (val.day, val.month, val.year)
            # val = val.replace(" ", "")
        except Exception as e:
            print "read error: {}".format(e)
        return val

    def getFirstCodeEmptyRow(self):
        row = 1
        while self.read(row, 5) != None:
            row += 1
        return row

    def getFirstEmptyRowByCol(self, col):
        row = 1
        while self.read(row, col) != None:
            row += 1
        return row

    def getFirstClientEmptyRow(self):
        row = 1
        while self.read(row, 2) != None:
            row += 1
        return row

    def getCurrentDate(self):
        dateOfToday = date.today()
        try:
            from urllib2 import urlopen
            res = urlopen('http://just-the-time.appspot.com/')
            time_str = res.read().strip()
            nowDay, nowTime = time_str.split(" ")
            y,m,d = nowDay.split("-")
            if int(y)>2017 and int(m)>0 and int(m)<13 and int(d)>0 and int(d)<32:
                dateOfToday = date(int(y), int(m), int(d))
        except:
            pass
        return dateOfToday

    def style_range(self):
        GREEN = "00B050"
        RED = "FF0000"
        YELLOW = "FFC000"

        emptyCodeRow = self.getFirstCodeEmptyRow()
        emptyClientRow = self.getFirstClientEmptyRow()
        al = Alignment(horizontal="center", vertical="center")

        for i in range(1,max(emptyCodeRow,emptyClientRow)):
            for j in range(1,8):
                self.ws.cell(column=j, row=i).alignment = al
                # self.ws.cell(column=j, row=i).number_format = 'General'
                if j == 6 and i > 1:
                    value = self.read(i,j)
                    if value != None:
                        d, m, y = value.split("/")
                        expDate = date(int(y), int(m), int(d))
                        days = (expDate - self.getCurrentDate()).days
                        if days > 30:
                            fo = Font(b=True, color=GREEN)
                        elif days < 0:
                            fo = Font(b=True, color=RED)
                        else:
                            fo = Font(b=True, color=YELLOW)
                        self.ws.cell(column=j, row=i).font = fo
