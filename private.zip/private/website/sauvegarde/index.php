<?php
// Powered by Infinityfree.net
if (version_compare(PHP_VERSION, '5.3.0') < 0) {
	echo "Your PHP version is outdated for this website. Please update PHP version to 5.3.6 or higher.";
	exit();
}
include dirname(__FILE__).'/sitepro/index.php';
?>