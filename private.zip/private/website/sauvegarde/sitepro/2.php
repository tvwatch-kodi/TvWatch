<!DOCTYPE html>
<html lang="fr">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Produits"); ?></title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1200" />
		<meta name="description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta name="keywords" content="<?php echo htmlspecialchars(($seoKeywords !== "") ? $seoKeywords : ""); ?>" />
	<!-- Facebook Open Graph -->
	<meta property="og:title" content="<?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Produits"); ?>" />
	<meta property="og:description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta property="og:image" content="<?php echo htmlspecialchars(($seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20190108105132" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20190111112710" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1547422565" rel="stylesheet" type="text/css" />
	<link href="css/2.css?ts=1547422565" rel="stylesheet" type="text/css" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance31" class="wb_element wb-menu"><ul class="hmenu"><li><a href="" target="_self">Accueil</a></li><li class="active"><a href="Tutoriels/" target="_self">Tutoriels</a></li><li><a href="Contacts/" target="_self">Contacts</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance32" class="wb_element wb_text_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="margin: 0cm 0cm 8pt;">TvWatch</h5>
</div><div id="wb_element_instance33" class="wb_element wb_element_picture" title=""><img alt="gallery/icon 100x100" src="gallery_gen/33a1a40d995822a70c13853eb7bb91ee.png"></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance35" class="wb_element wb_text_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Tutoriels</h1>
</div><div id="wb_element_instance36" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Installation de Kodi</h2>
</div><div id="wb_element_instance37" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance38" class="wb_element wb_text_element" style=" line-height: normal;"><ul><li class="wb-stl-normal">Télécharger Kodi pour Windows <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">L</a><a data-name="http://mirrors.kodi.tv/releases/windows/win32/kodi-17.6-Krypton-x86.exe" href="http://mirrors.kodi.tv/releases/windows/win32/kodi-17.6-Krypton-x86.exe">ien 1</a> ou <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">Lien 2</a></li>
	<li class="wb-stl-normal">Télécharger Kodi pour MacOS <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">L</a><a data-name="http://mirrors.kodi.tv/releases/osx/x86_64/kodi-17.6-Krypton-x86_64.dmg" href="http://mirrors.kodi.tv/releases/osx/x86_64/kodi-17.6-Krypton-x86_64.dmg">ien 1</a> ou <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">Lien 2</a></li>
	<li class="wb-stl-normal">Télécharger Kodi pour Linux <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">L</a><a data-name="http://kodi.wiki/view/HOW-TO:Install_Kodi_for_Linux" href="http://kodi.wiki/view/HOW-TO:Install_Kodi_for_Linux">ien 1</a> ou <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">Lien 2</a></li>
	<li class="wb-stl-normal">Télécharger Kodi pour Android <a data-name="https://kodi.tv/download" href="https://kodi.tv/download">G</a><a data-name="https://play.google.com/store/apps/details?id=org.xbmc.kodi" href="https://play.google.com/store/apps/details?id=org.xbmc.kodi">oogle Play</a></li>
	<li class="wb-stl-normal">Télécharger Kodi pour iOS <a data-name="http://mirrors.kodi.tv/releases/darwin/ios/org.xbmc.kodi-ios_17.6-0_iphoneos-arm.deb" href="http://mirrors.kodi.tv/releases/darwin/ios/org.xbmc.kodi-ios_17.6-0_iphoneos-arm.deb">Deb File</a></li>
</ul></div><div id="wb_element_instance39" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance40" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Installation de TvWatch</h2>
</div><div id="wb_element_instance41" class="wb_element"><iframe title="YouTube video player" class="youtube-player" allowfullscreen="" type="text/html" src="//www.youtube.com/embed/614nwd3J_x0?controls=1&amp;amp;showinfo=1" frameborder="0"></iframe></div><div id="wb_element_instance42" class="wb_element wb_text_element" style=" line-height: normal;"><p style="margin: 0cm 0cm 0.0001pt;"><span style="font-size:11pt"><span style="font-family:Calibri,sans-serif"><b><span style="font-size:16.0pt"><span style='font-family:"Arial",sans-serif'><span style="color:#63666a">Lien repository: <i>http://tvwatch2.000webhostapp.com/</i></span></span></span></b></span></span></p>
</div><div id="wb_element_instance43" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance44" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Mise à jour de TvWatch</h2>
</div><div id="wb_element_instance45" class="wb_element"><iframe title="YouTube video player" class="youtube-player" allowfullscreen="" type="text/html" src="//www.youtube.com/embed/iYWGKD64kM0?controls=1&amp;amp;showinfo=1" frameborder="0"></iframe></div><div id="wb_element_instance46" class="wb_element wb_text_element" style=" line-height: normal;"><p style="margin: 0cm 0cm 0.0001pt;"><font color="#63666a" face="Arial, sans-serif"><span style="font-size: 21.3333px;"><b>Méthode 1</b></span></font></p>
</div><div id="wb_element_instance47" class="wb_element wb_text_element" style=" line-height: normal;"><p style="margin: 0cm 0cm 0.0001pt;"><font color="#63666a" face="Arial, sans-serif"><span style="font-size: 21.3333px;"><b>Méthode 2</b></span></font></p>
</div><div id="wb_element_instance48" class="wb_element"><iframe title="YouTube video player" class="youtube-player" allowfullscreen="" type="text/html" src="//www.youtube.com/embed/ifuY8j-qy7g?controls=1&amp;amp;showinfo=1" frameborder="0"></iframe></div><div id="wb_element_instance49" class="wb_element"><iframe title="YouTube video player" class="youtube-player" allowfullscreen="" type="text/html" src="//www.youtube.com/embed/TkavBgCYH2E?controls=1&amp;amp;showinfo=1" frameborder="0"></iframe></div><div id="wb_element_instance50" class="wb_element wb_text_element" style=" line-height: normal;"><p style="margin: 0cm 0cm 0.0001pt;"><font color="#63666a" face="Arial, sans-serif"><span style="font-size: 21.3333px;"><b>Méthode 1</b></span></font></p>
</div><div id="wb_element_instance51" class="wb_element wb_text_element" style=" line-height: normal;"><p style="margin: 0cm 0cm 0.0001pt;"><font color="#63666a" face="Arial, sans-serif"><span style="font-size: 21.3333px;"><b>Méthode 2</b></span></font></p>
</div><div id="wb_element_instance52" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(2);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance52");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance52").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 131px;"><div id="wb_element_instance34" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-footer">© 2018 <a href="http://tvwatch.epizy.com">tvwatch.epizy.com</a></p></div><div id="wb_element_instance53" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
