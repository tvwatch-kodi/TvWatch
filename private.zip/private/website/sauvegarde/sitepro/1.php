<!DOCTYPE html>
<html lang="fr">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Accueil"); ?></title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1200" />
		<meta name="description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta name="keywords" content="<?php echo htmlspecialchars(($seoKeywords !== "") ? $seoKeywords : ""); ?>" />
	<!-- Facebook Open Graph -->
	<meta property="og:title" content="<?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Accueil"); ?>" />
	<meta property="og:description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta property="og:image" content="<?php echo htmlspecialchars(($seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20190108105132" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20190111112710" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1547422565" rel="stylesheet" type="text/css" />
	<link href="css/1.css?ts=1547422565" rel="stylesheet" type="text/css" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance0" class="wb_element wb-menu"><ul class="hmenu"><li class="active"><a href="" target="_self">Accueil</a></li><li><a href="Tutoriels/" target="_self">Tutoriels</a></li><li><a href="Contacts/" target="_self">Contacts</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance1" class="wb_element wb_text_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="margin: 0cm 0cm 8pt;">TvWatch</h5>
</div><div id="wb_element_instance2" class="wb_element wb_element_picture" title=""><img alt="gallery/icon 100x100" src="gallery_gen/33a1a40d995822a70c13853eb7bb91ee.png"></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance4" class="wb_element wb_element_picture" title=""><img alt="gallery/57449a16e43c4cb63c0d3c143fa56c27.media" src="gallery_gen/8b900255ccab677eeeacbda8f414359a_94x94.png"></div><div id="wb_element_instance5" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal"><em><strong>TvWatch </strong>est dispobnible sur Kodi.</em></p>

<p class="wb-stl-normal">Pour installer Kodi et TvWatch sur votre PC, téléphone ou tablette, visitez la rubrique <a data-name="Tutoriels" href="Tutoriels/">tutoriels</a></p>
</div><div id="wb_element_instance6" class="wb_element wb_text_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Installation</h1>
</div><div id="wb_element_instance7" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal" style="text-align: center;"><span style="font-size:16pt"><span style="line-height:107%"><span style='font-family:"Calibri Light",sans-serif'><span style="color:#2f5496"><span style="font-weight:normal"><strong><i><span lang="FR" style="border:none windowtext 1.0pt; font-size:19.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">Vous aimez notre produit ?</span></span></span></span></i></strong></span></span></span></span></span></p>

<p class="wb-stl-normal" style="text-align: center;"><strong><i><span lang="FR" style="border:none windowtext 1.0pt; font-size:19.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">Abonnez-vous vite !</span></span></span></span></i></strong></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="font-size:16pt"><span style="line-height:107%"><span style='font-family:"Calibri Light",sans-serif'><span style="color:#2f5496"><span style="font-weight:normal"><strong><em><span style="border:none windowtext 1.0pt; font-size:27.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">9.99</span></span></span></span></em><i><span style="border:none windowtext 1.0pt; font-size:27.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">€/3mois</span></span></span></span></i></strong></span></span></span></span></span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="font-size:16pt"><span style="line-height:107%"><span style='font-family:"Calibri Light",sans-serif'><span style="color:#2f5496"><span style="font-weight:normal"><strong><i><span style="border:none windowtext 1.0pt; font-size:27.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">14.99€/6mois</span></span></span></span></i></strong></span></span></span></span></span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="font-size:16pt"><span style="line-height:107%"><span style='font-family:"Calibri Light",sans-serif'><span style="color:#2f5496"><span style="font-weight:normal"><strong><i><span style="border:none windowtext 1.0pt; font-size:27.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">24.99€/12mois</span></span></span></span></i></strong></span></span></span></span></span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal" style="text-align: center;"><strong><i><span lang="FR" style="border:none windowtext 1.0pt; font-size:19.0pt; padding:0cm"><span style="line-height:107%"><span style='font-family:"inherit",serif'><span style="color:#993366">1 an d'abonnement gratuit par parrainage !!!</span></span></span></span></i></strong></p>
</div><div id="wb_element_instance8" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-custom1"><span style="color:#ffffff;">Contactez-nous avec vos coordonnées, nous vous répondrons dans les plus brefs délais avec un accès premium à toutes les </span>fonctionnalités <span style="color:#ffffff;">de TvWatch</span></p>

<p class="wb-stl-custom1"> </p>

<p class="wb-stl-custom1"><span style="color:#ffffff;">Visitez la rubrique <a data-name="Contacts" href="Contacts/"><u><em>Contacts</em></u></a></span></p>
</div><div id="wb_element_instance9" class="wb_element wb_text_element" style=" line-height: normal;"><ul><li class="wb-stl-custom1">Multiplatformes</li>
	<li class="wb-stl-custom1">Derniers Films et Séries</li>
	<li class="wb-stl-custom1">HD 720p &amp; 1080p</li>
	<li class="wb-stl-custom1">Visionnage illimité</li>
	<li class="wb-stl-custom1">Mode Offline (bêta)</li>
	<li class="wb-stl-custom1">Support 24/7</li>
</ul></div><div id="wb_element_instance10" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance11" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance12" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance13" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance14" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Fonctionnalités</h2>
</div><div id="wb_element_instance15" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2"><a href="">A</a>bonnez-vous !</h2>
</div><div id="wb_element_instance16" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Essai Premium 48H</h2>
</div><div id="wb_element_instance17" class="wb_element wb_element_picture" title=""><img alt="gallery/mac" src="gallery_gen/8da2357ecebe2d4b0cfa047840b9024d.png"></div><div id="wb_element_instance18" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance19" class="wb_element"><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank" class="paypal"><input type="hidden" name="cmd" value="_xclick"><input type="hidden" name="business" value="tvwatch.kodi@outlook.com"><input type="hidden" name="lc" value="US"><input type="hidden" name="item_name" value="Abonnement Trimestriel TvWatch"><input type="hidden" name="amount" value="9.99"><input type="hidden" name="currency_code" value="EUR"><input type="hidden" name="button_subtype" value="services"><input type="hidden" name="no_note" value="0"><input type="hidden" name="shipping" value="0"><input type="hidden" name="bn" value="JSCProfis_SP"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1"></form><script type="text/javascript">
			(function() { var img = $("#wb_element_instance19 form input[type=image]").get(0); if (img) { img.onload = function() { $("#wb_element_instance19").css({ minWidth: this.width + "px", width: this.width + "px", height: this.height + "px" }); }; } })();</script></div><div id="wb_element_instance20" class="wb_element"><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank" class="paypal"><input type="hidden" name="cmd" value="_xclick"><input type="hidden" name="business" value="tvwatch.kodi@outlook.com"><input type="hidden" name="lc" value="US"><input type="hidden" name="item_name" value="Abonnement Semestriel TvWatch"><input type="hidden" name="amount" value="14.99"><input type="hidden" name="currency_code" value="EUR"><input type="hidden" name="button_subtype" value="services"><input type="hidden" name="no_note" value="0"><input type="hidden" name="shipping" value="0"><input type="hidden" name="bn" value="JSCProfis_SP"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1"></form><script type="text/javascript">
			(function() { var img = $("#wb_element_instance20 form input[type=image]").get(0); if (img) { img.onload = function() { $("#wb_element_instance20").css({ minWidth: this.width + "px", width: this.width + "px", height: this.height + "px" }); }; } })();</script></div><div id="wb_element_instance21" class="wb_element"><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank" class="paypal"><input type="hidden" name="cmd" value="_xclick"><input type="hidden" name="business" value="tvwatch.kodi@outlook.com"><input type="hidden" name="lc" value="US"><input type="hidden" name="item_name" value="Abonnement Annuel TvWatch"><input type="hidden" name="amount" value="24.99"><input type="hidden" name="currency_code" value="EUR"><input type="hidden" name="button_subtype" value="services"><input type="hidden" name="no_note" value="0"><input type="hidden" name="shipping" value="0"><input type="hidden" name="bn" value="JSCProfis_SP"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1"></form><script type="text/javascript">
			(function() { var img = $("#wb_element_instance21 form input[type=image]").get(0); if (img) { img.onload = function() { $("#wb_element_instance21").css({ minWidth: this.width + "px", width: this.width + "px", height: this.height + "px" }); }; } })();</script></div><div id="wb_element_instance22" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance23" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Parrainage</h2>
</div><div id="wb_element_instance24" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-custom2">TvWatch vous offre <em><strong>1 an d'abonnement gratuit </strong></em>par parrainage effectif pour vous et votre filleul.</p>

<p class="wb-stl-custom2"> </p>

<p class="wb-stl-custom2">Pour valider le parrainage, le filleul doit nous envoyer le code du parrain dans la rubrique <u><a data-name="Contacts" href="Contacts/"><span style="color:rgba(255,255,255,1);">contacts</span></a></u><a data-name="Contacts" href="Contacts/"><span style="color:rgba(255,255,255,1);"> </span></a>avant la souscription.</p>
</div><div id="wb_element_instance25" class="wb_element"><div><iframe scrolling="no" allowTransparency="true" src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FTvWatch-385240871988297%2F&amp;tabs=&amp;locale=en_US&amp;small_header=true&amp;hide_cover=false&amp;show_facepile=false&amp;tabs=&amp;width=200&amp;height=70&amp;adapt_container_width=true" frameborder="0"></iframe></div><script type="text/javascript">(function() { var resizeTimeout = null; var resizeHandler = function() { var iframe = $('#wb_element_instance25 > div > iframe'), elem = $('#wb_element_instance25'); var iw = iframe.width(), ih = iframe.height(); var cw = elem.width(), ch = elem.height(); if (iw != cw || ih != ch) { clearTimeout(resizeTimeout); (function(w, h) { resizeTimeout = setTimeout(function() { iframe.attr('width', w).attr('height', h).css({ width: w + 'px', height: h + 'px' }); iframe.attr('src', iframe.attr('src').replace(/width=(\d+)/i, 'width=' + w).replace(/height=(\d+)/i, 'height=' + h)); elem.children('div').empty().append(iframe); }, 500);})(cw, ch); } }; $(window).on('resize', resizeHandler); resizeHandler(); setTimeout(function() { resizeHandler(); }, 2000); })();</script></div><div id="wb_element_instance26" class="wb_element"><iframe title="YouTube video player" class="youtube-player" allowfullscreen="" type="text/html" src="//www.youtube.com/embed/QwBiXrO2PZo?controls=1&amp;amp;showinfo=1" frameborder="0"></iframe></div><div id="wb_element_instance27" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance28" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Code d'essai: 2019. Valable jusqu'au 01/06/2019</h2>
</div><div id="wb_element_instance29" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(1);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance29");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance29").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 131px;"><div id="wb_element_instance3" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-footer">© 2018 <a href="http://tvwatch.epizy.com">tvwatch.epizy.com</a></p></div><div id="wb_element_instance30" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
