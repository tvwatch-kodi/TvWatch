#-*- coding: utf-8 -*-

import urllib2
import time
print "Test DL"

# url = "http://www53.uptobox.com/dl/wrvZFEuFFeWb7loxUnFYL2bjFeWpwOWWzK-V-Z3Cg5_f0LfSl5pyAHsnmqNF3zzoUnTW0kA3mNi75BiJjfaFA00QS7HY_yyvPCuZJGo7s0kYN3ddwUR58fUPwLakOARCYYLt_1RV6lUMGJZG0gnGjQ/K.The.Golden.C.2017.FRENCH.BDRip.x264-VENUE-WwW.Zone-Telechargement.Ws.mkv"
# file_name = url.split('/')[-1]

url = raw_input("\nEnter URL to download: ")
file_name = raw_input("\nEnter Filename: ")
u = urllib2.urlopen(url)
f = open(file_name, 'wb')
meta = u.info()
file_size = int(meta.getheaders("Content-Length")[0])
print "Downloading: %s Size: %sMB" % (file_name, file_size/1024/1024)

file_size_dl = 0
block_sz = 1024*1024
start = time.time()
while True:
    buf = u.read(block_sz)
    if not buf:
        break

    file_size_dl += len(buf)
    f.write(buf)
    now = time.time()
    speed = len(buf)/(now - start)/1024
    status = r"%10dMB  [%3.2f%%] %10dKB/s" % (file_size_dl/1024/1024, file_size_dl * 100. / file_size, speed)
    status = status + chr(8)*(len(status)+1)
    print status,
    start = now

f.close()

print "Download complete !\n"
raw_input("\nPress Enter to quit...")
