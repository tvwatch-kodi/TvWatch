#-*- coding: utf-8 -*-

print "*** Manage Infos ***\n"

from mySqlDB import cMySqlDB
from excel import cClientManager

mySqlDB = cMySqlDB()
excel = cClientManager('infos')

NAME      = 1
INFO      = 2

def updateDatabase(max):
    for i in range(2, max):
        meta = {}
        meta['name'] = excel.read(i, NAME)
        meta['info'] = excel.read(i, INFO)

        if not mySqlDB.insertContentInfo(meta):
            mySqlDB.updateContentInfo(meta)
    print "*** Database updated successfully ***"

def updateExcel(max):
    force = True
    for i in range(2, max):
        entry = mySqlDB.getContentByName(str(excel.read(i, NAME)))
        if entry:
            excel.write(i, INFO, entry[2], force)
    print "*** Excel updated successfully ***"

def resetTableInfo():
    mySqlDB.deleteTableInfo()
    mySqlDB.createTableInfo()

#################################################################################################
if excel.getFirstEmptyRowByCol(NAME) != excel.getFirstEmptyRowByCol(INFO):
    print "ERROR: Mismatch between NAME/INFO rows"
    quit()

# USE WITH CAUTION
# resetTableInfo()
# print "*** Table Reset Successfully ***"
##################

emptyInfoRow = excel.getFirstEmptyRowByCol(NAME)
updateDatabase(emptyInfoRow)
updateExcel(emptyInfoRow)

for i in mySqlDB.getContentInfo():
   print i

print
mySqlDB.getDbSize()

del excel
del mySqlDB

raw_input("\nPress Enter to quit...")
