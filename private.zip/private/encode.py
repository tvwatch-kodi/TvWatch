#-*- coding: utf-8 -*-


import base64

print "DECODE 64"

myList = [ '0000', \
           '01/01/1970', \
           'tvWatchCode', \
           'Authentification', \
           'expirationDate', \
           'isPlaying', \
           'mySelfPlay', \
           'clientID', \
           'userN', \
           'passW', \
           'xfss', \
           'sponsorship', \

           '30421', \
           '30306', \
           '30442', \
           '30450', \
           '30437', \
           '30460', \

           'from resources.lib.primatech import OO0o', \
           'boo = OO0o().cC0OO()', \
           'quit()', \
           'primatech()', \
           'from resources.lib.util import primatech', \

           'sql11.freemysqlhosting.net', \
           'sql11217561', \
           'Wdfqrjffkk', \

           'ftp.epizy.com', \
           'epiz_21564884', \
           'code7461', \

           'self.mySqlDB.updateIP(str(int(self.currentTime)), self.clientID)', \
           'self.mySqlDB.updateIP("0", self.clientID)', \
           '_ = cMySqlDB().getContentFromServerTable()', \

           'zakaria220', \
           'code7461+' \

            ]

"""
0000 : MDAwMA==
01/01/1970 : MDEvMDEvMTk3MA==
tvWatchCode : dHZXYXRjaENvZGU=
Authentification : QXV0aGVudGlmaWNhdGlvbg==
expirationDate : ZXhwaXJhdGlvbkRhdGU=
isPlaying : aXNQbGF5aW5n
mySelfPlay : bXlTZWxmUGxheQ==
clientID : Y2xpZW50SUQ=
userN : dXNlck4=
passW : cGFzc1c=
xfss : eGZzcw==
sponsorship : c3BvbnNvcnNoaXA=
30421 : MzA0MjE=
30306 : MzAzMDY=
30442 : MzA0NDI=
30450 : MzA0NTA=
30437 : MzA0Mzc=
30460 : MzA0NjA=
from resources.lib.primatech import OO0o : ZnJvbSByZXNvdXJjZXMubGliLnByaW1hdGVjaCBpbXBvcnQgT08wbw==
boo = OO0o().cC0OO() : Ym9vID0gT08wbygpLmNDME9PKCk=
quit() : cXVpdCgp
primatech() : cHJpbWF0ZWNoKCk=
from resources.lib.util import primatech : ZnJvbSByZXNvdXJjZXMubGliLnV0aWwgaW1wb3J0IHByaW1hdGVjaA==
sql11.freemysqlhosting.net : c3FsMTEuZnJlZW15c3FsaG9zdGluZy5uZXQ=
sql11217561 : c3FsMTEyMTc1NjE=
Wdfqrjffkk : V2RmcXJqZmZraw==
ftp.epizy.com : ZnRwLmVwaXp5LmNvbQ==
epiz_21564884 : ZXBpel8yMTU2NDg4NA==
code7461 : Y29kZTc0NjE=
self.mySqlDB.updateIP(str(int(self.currentTime)), self.clientID) : c2VsZi5teVNxbERCLnVwZGF0ZUlQKHN0cihpbnQoc2VsZi5jdXJyZW50VGltZSkpLCBzZWxmLmNsaWVudElEKQ==
self.mySqlDB.updateIP("0", self.clientID) : c2VsZi5teVNxbERCLnVwZGF0ZUlQKCIwIiwgc2VsZi5jbGllbnRJRCk=
zakaria220 : emFrYXJpYTIyMA==
code7461+ : Y29kZTc0NjEr
"""

for i in myList:
    print i + " : " + base64.b64encode(i)

raw_input("\nPress Enter to quit...")
