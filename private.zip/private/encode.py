#-*- coding: utf-8 -*-


import base64

print "DECODE 64"

myList = [ '0000', \
           '01/01/1970', \
           'tvWatchCode', \
           'Authentification', \
           'expirationDate', \
           'isPlaying', \
           'mySelfPlay', \
           'clientID', \
           'userN', \
           'passW', \
           'xfss', \
           'sponsorship', \

           '30421', \
           '30306', \
           '30442', \
           '30450', \
           '30437', \
           '30460', \

           'from resources.lib.primatech import OO0o', \
           'boo = OO0o().cC0OO()', \
           'quit()', \
           'primatech()', \
           'from resources.lib.util import primatech', \

           'sql11.freemysqlhosting.net', \
           'sql11217561', \
           'Wdfqrjffkk', \

           'ftp.epizy.com', \
           'epiz_21564884', \
           'code7461', \

           'self.mySqlDB.updateIP(str(int(self.currentTime)), self.clientID)', \
           'self.mySqlDB.updateIP("0", self.clientID)', \
           '_ = cMySqlDB().getContentFromServerTable()', \

           'zakaria220', \
           'code7461+', \
           '_=(self.oConfig.getSetting("clientID")!="35")', \
           '_=(self.oConfig.getSetting("tvWatchCode")=="666")', \
           'self.userN, self.passW = "zakaria220$code7461+".split("$")', \
		   
		   'remotemysql.com', \
           'Iu378jjZCD', \
           'xVYo2M6brO', \
		   'Iu378jjZCD' \
           ]

data = ""
for i in myList:
    data += str(i) + " : " + str(base64.b64encode(i))
    data += "\n"
    print(str(i) + " : " + str(base64.b64encode(i)))

file = open("encode.txt", "w")
file.write(data)
file.close()

raw_input("\nPress Enter to quit...")
