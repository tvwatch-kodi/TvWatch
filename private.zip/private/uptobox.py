import urllib2,urllib
import requests

UA = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0'
headers = { 'User-Agent' : UA }

class NoRedirection(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        code, msg, hdrs = response.code, response.msg, response.info()

        return response

    https_response = http_response

url = 'https://uptobox.com/?op=login&referer=homepage/'
post_data = {}
post_data['login'] = 'zakaria220'
post_data['password'] = 'code7461+'

data = urllib.urlencode(post_data)

opener = urllib2.build_opener(NoRedirection)

opener.addheaders = [('User-agent', UA)]
opener.addheaders.append (('Content-Type', 'application/x-www-form-urlencoded'))
opener.addheaders.append (('Referer', str(url) ))
opener.addheaders.append (('Content-Length', str(len(data))))

try:
    response = opener.open(url,data)
    head = response.info()
except urllib2.URLError, e:
    print e

xfss = ''
connected = False
if 'xfss' in head['Set-Cookie']:
    connected = True
    xfss = head['Set-Cookie'].replace(' ','')
    a = xfss.find('xfss=')
    b = xfss.find(';',a)
    xfss = xfss[a+5:b]

print head
print 'Connected ' + str(connected)
print xfss

# req = urllib2.Request(url, None, headers)
# cookie = "xfss=c88m831374zy33ki;"
# req.add_header('cookie', cookie)
# req.add_header('dnt', '1')
# req.add_header('upgrade-insecure-requests', '1')
# # req.add_data(urllib.urlencode(post_data))
#
# try:
#     response = urllib2.urlopen(req)
# except urllib2.URLError, e:
#     print "debug" + str(getattr(e, "code", None))
#     print "debug" + str(getattr(e, "reason", None))
#
# sHtmlContent = response.read()
# head = response.headers
# response.close()
#
# print head
# print 'Connected ' + str('op=my_account' in sHtmlContent)
