#-*- coding: utf-8 -*-

import os
import mysql.connector

PROXY = "PITC-Zscaler-EMEA-London3PR.proxy.corporate.ge.com:80"

class cMySqlDB:

	# freemysqlhosting
    # hostname = "sql11.freemysqlhosting.net"
    # username = "sql11217561"
    # password = "Wdfqrjffkk"
    # dbName = "sql11217561"
    # timeout = 5

	# remotemysql
    hostname = "remotemysql.com"
    username = "Iu378jjZCD"
    password = "xVYo2M6brO"
    dbName = "Iu378jjZCD"
    timeout = 5
    PROXY_APPLIED = False

	# epizy
    # hostname = "sql208.epizy.com"
    # username = "epiz_21564884"
    # password = "code7461"
    # dbName = "epiz_21564884_ali"
    # timeout = 5

    def __init__(self):
        try:
            self.connect()
            # self.deleteTable()
            # print ("Init cMySqlDB SUCCESS")
        except mysql.connector.Error as e:
            if not self.PROXY_APPLIED:
                self.applyProxy()
                self.connect()
            else:
                print ("Init cMySqlDB FAIL: " + e.msg)
                quit()

    def __del__(self):
        try:
            self.dbcur.close()
            self.db.close()
            # print ("Destroy cMySqlDB SUCCESS")
        except mysql.connector.Error as e:
            print ("Destroy cMySqlDB FAIL: " + e.msg)

    def applyProxy(self):
        os.environ['HTTPS_PROXY'] = "https://" + PROXY
        os.environ['https_proxy'] = "https://" + PROXY
        os.environ['HTTP_PROXY'] = "http://" + PROXY
        os.environ['http_proxy'] = "https://" + PROXY
        self.PROXY_APPLIED = True

    def connect(self):
        self.db = mysql.connector.connect(host=self.hostname, \
                                          user=self.username, \
                                          password=self.password, \
                                          database=self.dbName, \
                                          connection_timeout=self.timeout)
        self.dbcur = self.db.cursor()

    def createTableMain(self):
        query = """CREATE TABLE IF NOT EXISTS mainTable (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    prenom VARCHAR(50) NOT NULL,
                    nom VARCHAR(50) NOT NULL,
                    code VARCHAR(73) NOT NULL UNIQUE,
                    expDate VARCHAR(10) NOT NULL,
                    ip VARCHAR(5) NOT NULL
                    );"""
        try:
            self.dbcur.execute(query)
            # print ('Table MySQL initialized')
            return True
        except mysql.connector.Error as e:
            print ('MySQL ERROR createTableMain: ' + e.msg)
            return False

    def insertContentMain(self, meta):
        if self.getContentByCode(meta['code']) != None:
            return False
        try:
            ex = """INSERT INTO mainTable (prenom, nom, code, expDate, ip)
                    VALUES(%(prenom)s, %(nom)s, %(code)s, %(expDate)s, %(ip)s)"""
            self.dbcur.execute(ex, meta)
            self.db.commit()
            # print ('SQL INSERT table Successfully')
            return True
        except mysql.connector.Error as e:
            print ('SQL ERROR INSERT table: ' + e.msg)
            return False

    def updateContentMain(self, meta):
        try:
            ex = """UPDATE mainTable
                    SET prenom = %(prenom)s,
                        nom = %(nom)s,
                        code = %(code)s,
                        expDate = %(expDate)s
                    WHERE code = %(code)s"""
            self.dbcur.execute(ex, meta)
            self.db.commit()
            # print ('SQL UPDATE table Successfully')
        except mysql.connector.Error as e:
            print ('SQL ERROR UPDATE table: ' + e.msg)

    def updateIsPlayingByClientID(self, ip, clientID):
        if ip:
            try:
                ex = """UPDATE mainTable
                        SET ip = %s
                        WHERE id = %s"""
                self.dbcur.execute(ex, (ip, clientID))
                self.db.commit()
                # print ('SQL UPDATE table Successfully: ip with ' + ip)
                return True
            except mysql.connector.Error as e:
                print ('SQL ERROR UPDATE table ip: ' + e.msg)
                return False

    def getContentMain(self):
        query = "SELECT * FROM mainTable"
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchall()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def getRegisteredCodes(self):
        query = "SELECT code FROM mainTable"
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchall()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def getContentByCode(self, code):
        query = "SELECT * FROM mainTable WHERE code = '%s'" % (code)
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchone()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def delContentByID(self, clientID):
        query = "DELETE FROM mainTable WHERE id = '%s'"  % (clientID)
        try:
            self.dbcur.execute(query)
            self.db.commit()
            # print ('delContentByID: successfully')
        except mysql.connector.Error as e:
            print ('SQL ERROR DELETE table: ' + e.msg)

    def delContentByCode(self, clientCode):
        query = "DELETE FROM mainTable WHERE code = '%s'"  % (clientCode)
        try:
            self.dbcur.execute(query)
            self.db.commit()
            # print ('delContentByID: successfully')
        except mysql.connector.Error as e:
            print ('SQL ERROR DELETE table: ' + e.msg)

    def deleteTableMain(self):
        try:
            self.dbcur.execute("DROP TABLE IF EXISTS mainTable")
            # print ("deleteTable SUCCESS")
        except:
            print ("deleteTable mainTable FAIL")

    def createTableServer(self):
        query = """CREATE TABLE IF NOT EXISTS serverTable (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    country VARCHAR(20) NOT NULL,
                    city VARCHAR(20) NOT NULL,
                    server VARCHAR(25) NOT NULL,
                    xfss VARCHAR(16) NOT NULL,
                    UNIQUE (country,server)
                    );"""
        try:
            self.dbcur.execute(query)
            # print ('Table MySQL initialized')
            return True
        except mysql.connector.Error as e:
            print ('MySQL ERROR createTableServer: ' + e.msg)
            return False

    def insertContentServer(self, meta):
        if self.uniqueTestServer(meta) != None:
            return False
        try:
            ex = """INSERT INTO serverTable (country, city, server, xfss)
                    VALUES(%(country)s, %(city)s, %(server)s, %(xfss)s)"""
            self.dbcur.execute(ex, meta)
            self.db.commit()
            # print ('SQL INSERT table Successfully')
            return True
        except mysql.connector.Error as e:
            print ('SQL ERROR INSERT table: ' + e.msg)
            return False

    def updateContentServer(self, meta):
        try:
            ex = """UPDATE serverTable
                    SET country = %(country)s,
                        city = %(city)s,
                        server = %(server)s
                    WHERE server = %(server)s"""
            self.dbcur.execute(ex, meta)
            self.db.commit()
            # print ('SQL UPDATE table Successfully')
        except mysql.connector.Error as e:
            print ('SQL ERROR UPDATE table: ' + e.msg)

    def getContentServer(self):
        query = "SELECT * FROM serverTable"
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchall()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def getContentByServer(self, server):
        query = "SELECT * FROM serverTable WHERE server = '%s'" % (server)
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchone()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def getContentByLocation(self, location):
        query = """SELECT * FROM serverTable
                   WHERE country = %(country)s, city = %(city)s"""
        try:
            self.dbcur.execute(query, location)
            res = self.dbcur.fetchone()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def uniqueTestServer(self, meta):
        query = """SELECT * FROM serverTable
                   WHERE country = %(country)s AND server = %(server)s AND city = %(city)s"""
        try:
            self.dbcur.execute(query, meta)
            res = self.dbcur.fetchone()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def deleteTableServer(self):
        try:
            self.dbcur.execute("DROP TABLE IF EXISTS serverTable")
            # print ("deleteTable SUCCESS")
        except:
            print ("deleteTable serverTable FAIL")

    def createTableInfo(self):
        query = """CREATE TABLE IF NOT EXISTS infoTable (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(20) NOT NULL,
                    info VARCHAR(100) NOT NULL,
                    UNIQUE (name)
                    );"""
        try:
            self.dbcur.execute(query)
            # print ('Table MySQL initialized')
            return True
        except mysql.connector.Error as e:
            print ('MySQL ERROR createTableInfo: ' + e.msg)
            return False

    def insertContentInfo(self, meta):
        if self.uniqueTestInfo(meta) != None:
            return False
        try:
            ex = """INSERT INTO infoTable (name, info)
                    VALUES(%(name)s, %(info)s)"""
            self.dbcur.execute(ex, meta)
            self.db.commit()
            # print ('SQL INSERT table Successfully')
            return True
        except mysql.connector.Error as e:
            print ('SQL ERROR INSERT table: ' + e.msg)
            return False

    def updateContentInfo(self, meta):
        try:
            ex = """UPDATE infoTable
                    SET name = %(name)s,
                        info = %(info)s
                    WHERE name = %(name)s"""
            self.dbcur.execute(ex, meta)
            self.db.commit()
            # print ('SQL UPDATE table Successfully')
        except mysql.connector.Error as e:
            print ('SQL ERROR UPDATE table: ' + e.msg)

    def getContentInfo(self):
        query = "SELECT * FROM infoTable"
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchall()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def getContentByName(self, name):
        query = "SELECT * FROM infoTable WHERE name = '%s'" % (name)
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchone()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def uniqueTestInfo(self, meta):
        query = """SELECT * FROM infoTable
                   WHERE name = %(name)s"""
        try:
            self.dbcur.execute(query, meta)
            res = self.dbcur.fetchone()
            return res
        except mysql.connector.Error as e:
            print ('SQL ERROR GET table: ' + e.msg)
            return None

    def deleteTableInfo(self):
        try:
            self.dbcur.execute("DROP TABLE IF EXISTS infoTable")
            # print ("deleteTable SUCCESS")
        except:
            print ("deleteTable infoTable FAIL")

    def getDbSize(self):
        query = """ SELECT table_schema "DB Name",
                    Round(Sum(data_length + index_length) / 1024 / 1024, 2) "DB Size in MB"
                    FROM information_schema.tables
                    GROUP BY table_schema;"""
        try:
            self.dbcur.execute(query)
            res = self.dbcur.fetchall()
            #print ('Get Database size Successfully')
            availableSpace = str(100.0 - float(res[1][1])/5.0 * 100.0) + '%'
            self.printTables()
            print ('Size of %s: %sMB (Available Space %s)' % (res[1][0], res[1][1], availableSpace))
            return res
        except mysql.connector.Error as e:
            print ('MySQL ERROR getDbSize: ' + e.msg)
            return None

    def printTables(self):
        query = "SHOW TABLES"
        try:
            self.dbcur.execute(query)
            print (self.dbcur.fetchall())
        except mysql.connector.Error as e:
            print ('SQL ERROR printTables : ' + e.msg)
