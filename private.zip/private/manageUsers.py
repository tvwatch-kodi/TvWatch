#-*- coding: utf-8 -*-


print "*** Manage Database ***\n"

from mySqlDB import cMySqlDB
from password import cPassword
from excel import cClientManager
from random import randint

mySqlDB = cMySqlDB()
password = cPassword()
excel = cClientManager('main')

CLIENT_ID   = 1
FIRST_NAME  = 2
LAST_NAME   = 3
RAW_CODE    = 4
ENC_CODE    = 5
EXP_DATE    = 6
IS_PLAYING  = 7

def getNewCode(_emptyCodeRow):
    code = excel.read(_emptyCodeRow, RAW_CODE)
    if code != None:
        for i in range(2, _emptyCodeRow):
            if code == excel.read(i, RAW_CODE):
                print "The new code %s already exists in %d row" % (code, i)
                print "Please enter another one !"
                quit()
        return code, True

    while True:
        search = False
        code = randint(7461000000, 7461999999)
        for i in range(2, _emptyCodeRow):
            value = excel.read(i, RAW_CODE)
            if value != None:
                if int(value) == code:
                    search = True
                    break
        if not search:
            break
    return code, False

def createNewCodes(_emptyCodeRow, N):
    for i in range(_emptyCodeRow,_emptyCodeRow+N):
        code, force = getNewCode(i)
        enc = password.set_password(str(code))
        excel.write(i, RAW_CODE, code, force)
        excel.write(i, ENC_CODE, enc)

def updateDatabase(_emptyClientRow):
    for i in range(2,_emptyClientRow):
        meta = {}
        meta['prenom'] = excel.read(i, FIRST_NAME)
        meta['nom'] = excel.read(i, LAST_NAME)
        meta['code'] = excel.read(i, ENC_CODE)
        meta['expDate'] = excel.read(i, EXP_DATE)
        meta['ip'] = "0"

        if not mySqlDB.insertContentMain(meta):
            mySqlDB.updateContentMain(meta)

    _emptyCodeRow = excel.getFirstCodeEmptyRow()
    for code in mySqlDB.getRegisteredCodes():
        found = False
        for i in range(2,_emptyCodeRow):
            if excel.read(i, ENC_CODE) == code[0]:
                found = True
                break
        if not found:
            mySqlDB.delContentByCode(code[0])
    print "*** Database updated successfully ***"

def updateExcel(_emptyClientRow):
    force = True
    for i in range(2,_emptyClientRow):
        entry = mySqlDB.getContentByCode(str(excel.read(i, ENC_CODE)))
        if entry:
            excel.write(i, CLIENT_ID, int(entry[0]), force)
            excel.write(i, IS_PLAYING, int(entry[5]), force)
    print "*** Excel updated successfully ***"

def resetTableMain():
    mySqlDB.deleteTableMain()
    mySqlDB.createTableMain()

#################################################################################################
if excel.getFirstEmptyRowByCol(FIRST_NAME) != excel.getFirstEmptyRowByCol(LAST_NAME) or \
   excel.getFirstEmptyRowByCol(LAST_NAME) != excel.getFirstEmptyRowByCol(EXP_DATE) or \
   excel.getFirstEmptyRowByCol(EXP_DATE) != excel.getFirstEmptyRowByCol(FIRST_NAME):
    print "ERROR: Mismatch between FirstName/LastName/ExpiratinDate rows"
    quit()

# USE WITH CAUTION
# resetTableMain()
# print "*** Table Reset Successfully ***"
##################

emptyCodeRow = excel.getFirstCodeEmptyRow()
emptyClientRow = excel.getFirstClientEmptyRow()
numberOfCodesToCreate = emptyClientRow - emptyCodeRow
if numberOfCodesToCreate > 0:
    createNewCodes(emptyCodeRow, numberOfCodesToCreate)

updateDatabase(emptyClientRow)
updateExcel(emptyClientRow)

for i in mySqlDB.getContentMain():
   print i

print
mySqlDB.getDbSize()

del excel
del password
del mySqlDB

raw_input("\nPress Enter to quit...")
