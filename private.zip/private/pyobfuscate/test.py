#-*- coding: utf-8 -*-
# Primatech.
# https://github.com/Kodi-TvWatch/primatech-xbmc-addons
#
from resources . lib . config import cConfig
from resources . lib import util
from resources . lib . mySqlDB import cMySqlDB
from resources . lib . db import cDb
from resources . lib . gui . gui import cGui
import hashlib , uuid
import xbmc
if 64 - 64: i11iIiiIii
class OO0o :
 if 81 - 81: Iii1I1 + OO0O0O % iiiii % ii1I - ooO0OO000o
 def __init__ ( self ) :
  self . clientCode = '0000'
  self . clientExpDate = '01/01/1970'
  self . clientIsPlaying = ''
  self . nom = ""
  self . prenom = ""
  self . availableDays = ""
  self . permitUser = False
  self . oConfig = cConfig ( )
  if 4 - 4: IiII1IiiIiI1 / iIiiiI1IiI1I1
 def checkCredentials ( self ) :
  self . oConfig . log ( 'checkCredentials' )
  o0OoOoOO00 = 0
  self . clientCode = self . oConfig . getSetting ( 'tvWatchCode' )
  I11i = False
  while not self . isCodeValid ( ) :
   self . oConfig . log ( "Client code: " + self . clientCode )
   self . clientCode = self . oConfig . createDialogNum ( util . VSlang ( 30421 ) )
   I11i = True
   o0OoOoOO00 += 1
   if self . clientCode == '' or o0OoOoOO00 >= 3 :
    return False
  if self . permitUser :
   return True
  if self . isExpirationDateValid ( ) and self . accountNotInUse ( ) :
   if I11i :
    cGui ( ) . showInfo ( util . VSlang ( 30306 ) % self . prenom , util . VSlang ( 30442 ) % self . availableDays , 7 )
   return True
  else :
   return False
   if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
 def isCodeValid ( self ) :
  I11iIi1I = cMySqlDB ( ) . getContent ( )
  for IiiIII111iI in I11iIi1I :
   IiII , iI1Ii11111iIi = IiiIII111iI [ 3 ] . split ( "$" )
   if hashlib . sha1 ( self . clientCode + IiII ) . hexdigest ( ) == iI1Ii11111iIi :
    self . oConfig . setSetting ( 'tvWatchCode' , self . clientCode )
    cDb ( ) . insert_clientID ( str ( IiiIII111iI [ 0 ] ) )
    self . prenom = IiiIII111iI [ 1 ]
    self . nom = IiiIII111iI [ 2 ]
    self . clientExpDate = IiiIII111iI [ 4 ]
    self . clientIsPlaying = IiiIII111iI [ 5 ]
    if 41 - 41: I1II1
    return True
  if I11iIi1I == [ ] :
   self . permitUser = True
   self . oConfig . log ( 'isCodeValid ERROR' )
   self . oConfig . log ( 'permit the client to use the app' )
   return True
  self . oConfig . log ( 'isCodeValid NOK !' )
  return False
  if 100 - 100: iII1iII1i1iiI % iiIIIII1i1iI % iiI11iii111 % i1I1Ii1iI1ii
 def isExpirationDateValid ( self ) :
  from datetime import date
  II1iI , i1iIii1Ii1II , i1I1Iiii1111 = self . clientExpDate . replace ( " " , "" ) . split ( "/" )
  i11 = date ( int ( i1I1Iiii1111 ) , int ( i1iIii1Ii1II ) , int ( II1iI ) )
  I11 = self . oConfig . getCurrentDate ( )
  if i11 < I11 :
   self . oConfig . log ( 'isExpirationDateValid NOK !' )
   cGui ( ) . showInfo ( "Authentification" , util . VSlang ( 30450 ) , 3 )
   return False
  else :
   if 98 - 98: I1111 * o0o0Oo0oooo0 / I1I1i1 * I1I1i1 / ooO0OO000o
   self . availableDays = str ( ( i11 - I11 ) . days )
   self . oConfig . setSetting ( 'expirationDate' , self . availableDays )
   return True
   if 11 - 11: IiII1IiiIiI1 % ii1IiI1i - iIiiiI1IiI1I1
 def accountNotInUse ( self ) :
  oo0O000OoO = True
  i1iiIIiiI111 = self . oConfig . getSetting ( 'isPlaying' )
  if i1iiIIiiI111 == '' :
   self . oConfig . setSetting ( 'isPlaying' , self . clientIsPlaying )
  else :
   if int ( self . clientIsPlaying ) > int ( i1iiIIiiI111 ) :
    self . oConfig . setSetting ( 'isPlaying' , self . clientIsPlaying )
    self . oConfig . log ( 'accountNotInUse NOK !' )
    cGui ( ) . showInfo ( "Authentification" , util . VSlang ( 30437 ) , 3 )
    oo0O000OoO = False
  return oo0O000OoO
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
