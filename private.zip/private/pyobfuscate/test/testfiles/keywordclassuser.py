
import keywordclass
import sys

k = keywordclass.ClassWithKeywords(kwarg=20)

sys.exit(k.fortytwo(arg=22))
