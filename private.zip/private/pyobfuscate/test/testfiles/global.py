
import sys

def foo():
    return glob*2

def main():
    global glob
    glob = 21
    return foo()

sys.exit(main())
