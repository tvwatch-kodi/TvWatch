import sys

from package.tobeimported import foo

sys.exit(foo())
