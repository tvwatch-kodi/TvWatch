import sys

from tobeimported import foo

sys.exit(foo())

